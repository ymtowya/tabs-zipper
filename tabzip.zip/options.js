chrome.storage.sync.set({color: "@@"}, function () {
    console.log("something");
});